# 0x12. Web stack debugging #2 

<p align="center">
  <img src="https://i.postimg.cc/dVXBzkzc/99littlebugsinthecode.jpg"/>
</p>

## Tasks

<details>
<summary><a href="./0-iamsomeoneelse">0. Run software as another user</a></summary><br>
<a href='https://postimages.org/' target='_blank'><img src='https://i.postimg.cc/3JjzLYwh/power.png' border='0' alt='power'/></a>
<a href='https://postimages.org/' target='_blank'><img src='https://i.postimg.cc/cHZT1qTs/image.png' border='0' alt='image'/></a>
</details>

<details>
<summary><a href="./1-run_nginx_as_nginx">1. Run Nginx as Nginx</a></summary><br>
<a href='https://postimages.org/' target='_blank'><img src='https://i.postimg.cc/HnNDJ0Ss/image.png' border='0' alt='image'/></a>
</details>

<details>
<summary><a href="./100-fix_in_7_lines_or_less">2. 7 lines or less</a></summary><br>
<a href='https://postimages.org/' target='_blank'><img src='https://i.postimg.cc/pd9mQ0Jw/image.png' border='0' alt='image'/></a>
</details>
