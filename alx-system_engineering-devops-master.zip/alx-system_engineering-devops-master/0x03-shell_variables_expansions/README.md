Shell, init files and varibale expansion
